"""FastAPI routes."""
